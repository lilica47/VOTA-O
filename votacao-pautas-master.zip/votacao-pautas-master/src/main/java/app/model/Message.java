package app.model;

public class Message {

	public String type;

	public String title;

	public String description;

}
